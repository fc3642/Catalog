from sqlalchemy import Column, ForeignKey, Integer, String, DateTime, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()


class User(Base):
    __tablename__ = 'user'
    user_id = Column(Integer, primary_key=True)
    user_name = Column(String(250), nullable=False)
    user_email = Column(String(250), nullable=False)
    password_flash = Column(String(250))
    user_picture = Column(String(250))


class Category(Base):
    __tablename__ = 'category'
    # category_id= Column(Integer, primary_key=True)
    # category_name = Column(String(250), nullable=False)
    category_name = Column(String(250), primary_key=True)
    user_id = Column(Integer, ForeignKey('user.user_id'))
    user = relationship(User)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'category_name': self.category_name,
            'user_id': self.user_id,
        }


class CatalogItem(Base):
    __tablename__ = 'catalog_item'
    item_id = Column(Integer, primary_key=True)
    item_title = Column(String(80), nullable=False)
    item_description = Column(String(250))
    last_update = Column(DateTime)
    category_name = Column(Integer, ForeignKey('category.category_name'))
    category = relationship(Category)
    user_id = Column(Integer, ForeignKey('user.user_id'))
    user = relationship(User)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'item_id': self.item_id,
            'item_title': self.item_title,
            'item_description': self.item_description,
            'last_update': self.last_update,
            'category_name': self.category_name,
            'user_id': self.user_id,
        }


engine = create_engine('sqlite:///catalog.db')


Base.metadata.create_all(engine)
