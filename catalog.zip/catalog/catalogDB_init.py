from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import datetime
from catalogDB_setup import *

engine = create_engine('sqlite:///catalog.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
# A DBSession() instance establishes all conversations with the database
# and represents a "staging zone" for all the objects loaded into the
# database session object. Any change made against the objects in the
# session won't be persisted into the database until you call
# session.commit(). If you're not happy about the changes, you can
# revert all of them back to the last commit by calling
# session.rollback()
session = DBSession()

# Delete Categories if exisitng.
session.query(Category).delete()
# Delete Items if exisitng.
session.query(CatalogItem).delete()
# Delete Users if exisitng.
session.query(User).delete()

# Create fake users
User1 = User(user_name="Donald Trump",
             user_email="donaldtrump@skype.com",
             user_picture='http://dummyimage.com/200x200.png/ff4444/ffffff')
session.add(User1)
session.commit()

User2 = User(user_name="Barack Obama",
             user_email="barackobama@unitedstates.org",
             user_picture='http://dummyimage.com/200x200.png/cc0000/ffffff')
session.add(User2)
session.commit()


# Create fake categories
Category1 = Category(category_name="Soccer",
                     user_id=1)
session.add(Category1)
session.commit()

Category2 = Category(category_name="Basketball",
                     user_id=2)
session.add(Category2)
session.commit

Category3 = Category(category_name="Baseball",
                     user_id=1)
session.add(Category3)
session.commit()

Category4 = Category(category_name="Frisbee",
                     user_id=1)
session.add(Category4)
session.commit()

Category5 = Category(category_name="Snowboarding",
                     user_id=1)
session.add(Category5)
session.commit()

Category6 = Category(category_name="Rock Climbing",
                     user_id=1)
session.add(Category6)
session.commit()

Category7 = Category(category_name="Football",
                     user_id=1)
session.add(Category7)
session.commit()

Category8 = Category(category_name="Skating",
                     user_id=1)
session.add(Category8)
session.commit()

Category9 = Category(category_name="Hockey",
                     user_id=1)
session.add(Category9)
session.commit()

# Populate a category with items for testing
# Using different users for items also
Item1 = CatalogItem(item_title="Stick",
                    last_update=datetime.datetime.now(),
                    item_description="Stick Description",
                    category_name="Hockey",
                    user_id=1)
session.add(Item1)
session.commit()

Item2 = CatalogItem(item_title="Goggles",
                    last_update=datetime.datetime.now(),
                    item_description="Goggles Description",
                    category_name="Snowboarding",
                    user_id=1)
session.add(Item2)
session.commit()

Item3 = CatalogItem(item_title="Snowboard",
                    last_update=datetime.datetime.now(),
                    item_description="Snowboard Description",
                    category_name="Snowboarding",
                    user_id=1)
session.add(Item3)
session.commit()

Item4 = CatalogItem(item_title="Two shinguards",
                    last_update=datetime.datetime.now(),
                    item_description="Two shinguards Description",
                    category_name="Soccer",
                    user_id=1)
session.add(Item4)
session.commit()

Item5 = CatalogItem(item_title="Shinguards",
                    last_update=datetime.datetime.now(),
                    item_description="Shinguards Description",
                    category_name="Soccer",
                    user_id=1)
session.add(Item5)
session.commit()

Item6 = CatalogItem(item_title="Frisbee",
                    last_update=datetime.datetime.now(),
                    item_description="Frisbee Description",
                    category_name="Frisbee",
                    user_id=1)
session.add(Item6)
session.commit()

Item7 = CatalogItem(item_title="Bat",
                    last_update=datetime.datetime.now(),
                    item_description="Bat Description",
                    category_name="Baseball",
                    user_id=1)
session.add(Item7)
session.commit()

Item8 = CatalogItem(item_title="Jersey",
                    last_update=datetime.datetime.now(),
                    item_description="Jersey Description",
                    category_name="Soccer",
                    user_id=1)
session.add(Item8)
session.commit()

Item9 = CatalogItem(item_title="Soccer Cleats",
                    last_update=datetime.datetime.now(),
                    item_description="Soccer Cleats Description",
                    category_name="Soccer",
                    user_id=1)
session.add(Item9)
session.commit()

print "Your database has been populated with fake data!"
