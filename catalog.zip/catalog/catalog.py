from flask import Flask, render_template, request, redirect,\
                        jsonify, url_for, flash
from sqlalchemy import create_engine, asc, desc
from sqlalchemy.orm import sessionmaker
from catalogDB_setup import Base, Category, CatalogItem, User
from flask import session as login_session
from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import FlowExchangeError
from flask import make_response
from functools import wraps
import random
import string
import os
import datetime
import httplib2
import json
import requests
app = Flask(__name__)

CLIENT_ID = \
        json.loads(open('client_secrets.json', 'r').read())['web']['client_id']
# Connect to Database and create database session
engine = create_engine('sqlite:///catalog.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
catalogDBsession = DBSession()


def login_required(f):
    '''Check if the user is logged in'''
    @wraps(f)
    def x(*args, **kwargs):
         if 'username' not in login_session:
              return redirect('/login')
         return f(*args, **kwargs)
    return x


@app.route('/login')
def showLogin():
    '''Create a state token to prevent request forgery.
    Store it in the session for later validation.'''
    state = ''.join(random.choice(string.ascii_uppercase + string.digits)
              for x in xrange(32))
    login_session['state'] = state
    # Render the login template
    return render_template('login.html', STATE=state)


@app.route('/gconnect', methods=['POST'])
def gconnect():
    '''Login user to google account and redirect to the Catalog page'''
    print("Invoking gconnect")
    if request.args.get('state') != login_session['state']:
        response = make_response(json.dumps('Invalid state parameter'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    # obtain authorization code
    code = request.data
    try:
        # Upgrade the authorization code into a credentias object
        oauth_flow = flow_from_clientsecrets('client_secrets.json', scope='')
        oauth_flow.redirect_uri = 'postmessage'
        credentials = oauth_flow.step2_exchange(code)
    except FlowExchangeError:
        response = make_response(json.dumps('Failed to upgrate the authorization code.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Check that the access token is valid
    access_token = credentials.access_token
    url = ('https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=%s' % access_token)
    h = httplib2.Http()
    result = json.loads(h.request(url, 'GET')[1])
    # if there was an error in the access token info, abort.
    if result.get('error') is not None:
        response = make_response(json.dumps(result.get('error')), 500)
        response.headers['Content-type'] = 'application/json'
        return response
    # Verify that the access token is used for the intended user.
    gplus_id = credentials.id_token['sub']
    if result['user_id'] != gplus_id:
        response = make_response(json.dumps("Token's user ID doesn't match given user ID."), 401)
        response.headers['Content-Type'] = 'application/json'
        return response
    # Verify that the access token is valid for this app.
    if result['issued_to'] != CLIENT_ID:
        response = make_response(json.dumps("Token's client ID does not match app's."), 401)
        print("Token's client ID not match app's.")
        response.headers['Content-Type'] = 'application/json'
        return response
    # Check to see if user is already logged in
    stored_credentials = login_session.get('credentials')
    stored_gplus_id = login_session.get('gplus_id')
    if stored_credentials is not None and gplus_id == stored_gplus_id:
        response = make_response(json.dumps('Current user is already connected.'), 200)
        response.headers['Content-Type'] = 'application/json'
    # Store the access token in the session for later use.
    login_session['credentials'] = credentials.access_token
    login_session['gplus_id'] = gplus_id

    # Get user info
    userinfo_url = "https://www.googleapis.com/oauth2/v1/userinfo"
    params = {'access_token': credentials.access_token, 'alt' : 'json'}
    answer = requests.get(userinfo_url, params=params)

    data = answer.json()
    if 'name' not in data:
        login_session['username'] = "No Name"
    else:
        login_session['username'] = data["name"]
    login_session['picture'] = data["picture"]
    login_session['email'] = data["email"]

    # see if user exist, if it does not make a new one.
    user_id = getUserID(login_session['email'])
    if not user_id:
        user_id = createUser(login_session)
    login_session['user_id'] = user_id

    output = ''
    output += '<h1>Welcome, '
    output += login_session['username']
    output += '!</h1>'
    output += '<img src="'
    output += login_session['picture']
    output += ' " style = "width: 300px; height: 300px; border-radius: 150px; -webkit-border-radius: 150px; -moz-border-radius: 150px;"> '
    flash("You are now logged in as %s" % login_session['username'])
    return output


@app.route("/gdisconnect")
def gdisconnect():
    '''Disconnct - Revoke a current user's token and reset their login_session.'''
    # Only disconnect a connected user.
    credentials = login_session['credentials']
    if credentials is None:
        response = make_response(json.dumps('Current user not connected.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response
    # Execute HTTP GET request to revoke current token.
    access_token = credentials
    url = 'https://accounts.google.com/o/oauth2/revoke?token=%s' % access_token
    h = httplib2.Http()
    result = h.request(url, 'GET')[0]
    if result['status'] == '200':
        # Reset the user's session.
        del login_session['credentials']
        del login_session['gplus_id']
        del login_session['username']
        del login_session['email']
        del login_session['picture']
        # create a flash and redirect the user to the main page
        flash("Successfully Disconnected User")
        return redirect(url_for('showCatalog'))
    else:
        # For whatever reason, the given token was invalid.
        response = make_response(
            json.dumps('Failed to revoke token for given user.'), 400)
        response.headers['Content-Type'] = 'application/json'
        return response


@app.route('/catalog/json')
def catalogJSON():
    '''JSON APIs to view Catalog Information'''
    print("Entering catalogJSON")
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    category = catalogDBsession.query(Category).all()
    catalog_dict = [c.serialize for c in category]
    for c in range(len(catalog_dict)):
        catalog_items = [i.serialize for i in catalogDBsession.query(CatalogItem)
            .filter_by(category_name=catalog_dict[c]["category_name"]).all()]
        if catalog_items:
            catalog_dict[c]["Item"] = catalog_items
    return jsonify(Category=catalog_dict)


@app.route('/')
@app.route('/catalog/')
def showCatalog():
    '''Show all categories and latest Items'''
    print("Entering showCatalog")
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    categories = catalogDBsession.query(Category).order_by(asc(Category.category_name))
    catalog_items = catalogDBsession.query(CatalogItem).order_by(desc(CatalogItem.last_update)).limit(5)
    return render_template('catalog.html', categories=categories, items=catalog_items)


@app.route('/catalog/<path:category_name>/items/')
def showCategory(category_name):
    '''Show items in a category'''
    print("Entering showCategory")
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    categories = catalogDBsession.query(Category).order_by(asc(Category.category_name))
    category = catalogDBsession.query(Category).filter_by(category_name=category_name).one()
    items = catalogDBsession.query(CatalogItem).filter_by(category_name=category_name).order_by(asc(CatalogItem.item_title)).all()
    count = catalogDBsession.query(CatalogItem).filter_by(category_name=category_name).count()
    creator = getUserInfo(category.user_id)
    if 'username' not in login_session or creator.user_id != login_session['user_id']:
        # Render the public item page if the user is not logged in
        # or the user is not the original user who creates the category
        return render_template('public_items.html',
                categories=categories,
                items=items,
                count=count)
    else:
        user = getUserInfo(login_session['user_id'])
        # Render the category page which user can modify it.
        return render_template('items.html',
                category=category.category_name,
                categories=categories,
                items=items,
                count=count,
                user=user)


@app.route('/catalog/<path:item_id>/')
def showItem(item_id):
    '''Display a Specific Item '''
    print("Entering showItem")
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    catalog_item = catalogDBsession.query(CatalogItem).filter_by(item_id=item_id).one()
    creator = getUserInfo(catalog_item.user_id)
    categories = catalogDBsession.query(Category).order_by(asc(Category.category_name))
    if 'username' not in login_session or creator.user_id != login_session['user_id']:
        return render_template('public_itemdetail.html',
                item=catalog_item,
                categories=categories,
                creator=creator)
    else:
        return render_template('itemdetail.html',
                item=catalog_item,
                categories=categories,
                creator=creator)


@app.route('/catalog/addcategory', methods=['GET', 'POST'])
@login_required
def addCategory():
    '''Add a category'''
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    # Add the new category for POST method
    if request.method == 'POST':
        # show warning if the name is blank
        if request.form['name'].strip() == "":
            flash('Category Name Cannot Be Blank!')
            return render_template('addcategory.html')
        else:
            newCategory = Category(
                category_name=request.form['name'].strip(),
                user_id=login_session['user_id'])
            try:
                # except will catch if the cateory exists in the DB
                catalogDBsession.add(newCategory)
                catalogDBsession.commit()
                flash('Category Successfully Added!')
                return redirect(url_for('showCatalog'))
            except:
                flash("Category %s Already Exists" % request.form['name'])
                return render_template('addcategory.html')
    else:
        return render_template('addcategory.html')


@app.route('/catalog/<path:category_name>/editCategory', methods=['GET', 'POST'])
@login_required
def editCategory(category_name):
    '''Edit a category'''
    print("Entering editCategory with category_name=%s" % category_name)
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    editedCategory = catalogDBsession.query(Category).filter_by(category_name=category_name).one()
    category = catalogDBsession.query(Category).filter_by(category_name=category_name).one()
    # See if the logged in user is the owner of item
    creator = getUserInfo(editedCategory.user_id)
    user = getUserInfo(login_session['user_id'])
    # If logged in user != item owner redirect them
    if creator.id != login_session['user_id']:
        flash("You cannot edit this Category. This Category belongs to %s" % creator.name)
        return redirect(url_for('showCatalog'))
    # POST methods
    if request.method == 'POST':
        if request.form['name']:
            editedCategory.category_name = request.form['name']
        catalogDBsession.add(editedCategory)
        catalogDBsession.commit()
        flash('Category Item Successfully Edited!')
        return redirect(url_for('showCatalog'))
    else:
        return render_template('editcategory.html',
            categories=editedCategory,
            category=category)


@app.route('/catalog/<path:category_name>/deleteCagetory', methods=['GET', 'POST'])
@login_required
def deleteCategory(category_name):
    '''Delete a category'''
    print("Entering deleteCategory category_name = %s" % category_name)
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    categoryToDelete = catalogDBsession.query(Category).filter_by(category_name=category_name).one()
    # See if the logged in user is the owner of item
    creator = getUserInfo(categoryToDelete.user_id)
    user = getUserInfo(login_session['user_id'])
    # If logged in user != item owner redirect them
    if creator.user_id != login_session['user_id']:
        flash("You cannot delete this Category. This Category belongs to %s" % creator.name)
        return redirect(url_for('showCatalog'))
    if request.method =='POST':
        catalogDBsession.delete(categoryToDelete)
        catalogDBsession.commit()
        flash('Category Successfully Deleted! '+categoryToDelete.category_name)
        return redirect(url_for('showCatalog'))
    else:
        return render_template('deletecategory.html', category=categoryToDelete)


@app.route('/catalog/add', methods=['GET', 'POST'])
@login_required
def addItem():
    '''Add an catalog item'''
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    categories = catalogDBsession.query(Category).all()
    if request.method == 'POST':
        newItem = CatalogItem(
            item_title=request.form['name'],
            item_description=request.form['description'],
            category_name=request.form['category'],
            last_update=datetime.datetime.now(),
            user_id=login_session['user_id'])
        catalogDBsession.add(newItem)
        catalogDBsession.commit()
        flash('Item Successfully Added!')
        return redirect(url_for('showCatalog'))
    else:
        return render_template('additem.html',
            categories=categories)


@app.route('/catalog/<path:item_id>/editItem', methods=['GET', 'POST'])
@login_required
def editItem(item_id):
    '''Edit an catalog item'''
    print("Entering editItem, item_id=%s" % item_id)
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    editedItem = catalogDBsession.query(CatalogItem).filter_by(item_id=item_id).one()
    categories = catalogDBsession.query(Category).all()
    # See if the logged in user is the owner of item
    creator = getUserInfo(editedItem.user_id)
    user = getUserInfo(login_session['user_id'])
    # If logged in user != item owner redirect them
    if creator.user_id != login_session['user_id']:
        flash("You cannot edit this item. This item belongs to %s" % creator.user_name)
        return redirect(url_for('showCatalog'))
    # POST methods
    if request.method == 'POST':
        if request.form['name']:
            editedItem.item_title = request.form['name']
        if request.form['description']:
            editedItem.item_description = request.form['description']
        if request.form['category']:
            category = catalogDBsession.query(Category).filter_by(category_name=request.form['category']).one()
            editedItem.category_name = category.category_name
        editedItem.last_update = datetime.datetime.now()
        catalogDBsession.add(editedItem)
        catalogDBsession.commit()
        flash('Category Item Successfully Edited!')
        return  redirect(url_for('showCategory',
            category_name=editedItem.category_name))
    else:
        return render_template('edititem.html',
            item=editedItem,
            categories=categories)


@app.route('/catalog/<path:item_id>/deleteItem', methods=['GET', 'POST'])
@login_required
def deleteItem(item_id):
    '''Delete an item'''
    Print("Entering deleteItem")
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    itemToDelete = catalogDBsession.query(CatalogItem).filter_by(item_id=item_id).one()
    category = catalogDBsession.query(Category).filter_by(category_name=itemToDelete.category_name).one()
    categories = catalogDBsession.query(Category).all()
    # See if the logged in user is the owner of item
    creator = getUserInfo(itemToDelete.user_id)
    user = getUserInfo(login_session['user_id'])
    # If logged in user != item owner redirect them
    if creator.user_id != login_session['user_id']:
        flash("You cannot delete this item. This item belongs to %s" % creator.user_name)
        return redirect(url_for('showCatalog'))
    if request.method =='POST':
        catalogDBsession.delete(itemToDelete)
        catalogDBsession.commit()
        flash('Item Successfully Deleted! '+itemToDelete.item_title)
        return redirect(url_for('showCategory',
            category_name=category.category_name))
    else:
        return render_template('deleteitem.html',
            item=itemToDelete)


def getUserID(email):
    '''Get the logged in user for the given email'''
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    try:
        user = catalogDBsession.query(User).filter_by(user_email=email).one()
        return user.user_id
    except:
        return None


def getUserInfo(user_id):
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    user = catalogDBsession.query(User).filter_by(user_id=user_id).one()
    return user


def createUser(login_session):
    DBSession = sessionmaker(bind=engine)
    catalogDBsession = DBSession()
    newUser = User(user_name=login_session['username'], user_email=login_session['email'], user_picture=login_session['picture'])
    catalogDBsession.add(newUser)
    catalogDBsession.commit()
    user = catalogDBsession.query(User).filter_by(user_email=login_session['email']).one()
    return user.user_id


if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.debug = True
    app.run(host='0.0.0.0', port=8000)
