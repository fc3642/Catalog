The Catalog Project Is the Udacity Full Stack Web Developer Nano Degree 4th Project. This project provides a list of items within a variety 
of categories, as well as provides a user registration and authentication system. User without login will be able to view catalog and its items. 
For the logged in user, the application will allow user creating new catalogs and new items. 
It also provide user to edit the category or catalog item which were created by the logged in user previously.
Google  Oauth Credential will be used to manage user login. Application user must have a google account in order to edit/update categories 
or catalog items.

The project application also provides a json based API service to external applications to retrieve catalog/catalog items.

In order to set up and run the application, extract this package to a directly in a linux virtual box directory which has python and sqlalchemy installed.
Create a google application credential and download the client ID file, rename the file to client_secrets.json and store it to the application dir. 
run "python catalogDB_init.py" if you want to set up few base categories and items on the application dir.
Note: If the user starts with a blank Catalog DB, a category has to be created before any catalog items can be created.

The application uses port 8000 on the host machine, ensure this port is available and works properly on the VM and host machine.
run "python catalog.py" to start the application on the application dir.

On the host system browser, type localhost:8000 url to access the application.
Follow the on screen directions to navigate the application.
Enjoin the application! 
